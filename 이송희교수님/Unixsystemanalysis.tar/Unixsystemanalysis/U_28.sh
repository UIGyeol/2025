set -euo pipefail
PATTERN='ypserv|ypbind|ypxfrd|rpc\.yppasswdd|rpc\.ypupdated'

echo "== U-28 | NIS Legacy Action =="

# [점검 포인트]
echo "[점검 포인트]"
echo " - 프로세스: ps -eo pid,comm,cmd | egrep -E \"$PATTERN\""
echo " - 부팅 스크립트: /etc/rc.d/rc*.d/* 및 /etc/rc*.d/* (SysV 링크)"
echo

# 1) 실행 중인 NIS 관련 프로세스 check
PROC_LINES="$(ps -eo pid,comm,cmd --no-headers | egrep -E "$PATTERN" | egrep -v "egrep" || true)"
PIDS="$(printf '%s\n' "$PROC_LINES" | awk '{print $1}' 2>/dev/null || true)"

# 2) SysV 부팅 스크립트 탐지
mapfile -t RCFILES < <(ls -1 /etc/rc.d/rc*.d/* /etc/rc*.d/* 2>/dev/null | egrep -E "$PATTERN" || true)

# [탐지 결과] 없으면 해당 사항 아님
echo "[탐지 결과]"
if [ -n "${PROC_LINES:-}" ]; then
  echo " - 실행 중인 프로세스:"
  echo "$PROC_LINES"
else
  echo " - 실행 중인 프로세스: 없음"
fi

if [ ${#RCFILES[@]} -gt 0 ]; then
  echo " - 부팅 스크립트(S* 링크) 후보:"
  for f in "${RCFILES[@]}"; do echo "   * $f"; done
else
  echo " - 부팅 스크립트: 없음"
fi
echo

if [ -z "${PROC_LINES:-}" ] && [ ${#RCFILES[@]} -eq 0 ]; then
  echo "=> 해당사항 아님: NIS 관련 프로세스/부팅 스크립트 미발견"
  exit 0
fi

# [조치] 원인→근거→행동
echo "[조치 시작]"

# (A) 데몬 강제 종료
if [ -n "${PIDS:-}" ]; then
  echo " - 원인: NIS 관련 데몬 동작 중 → 보안상 비권장"
  echo " - 근거: 위 '실행 중인 프로세스' 목록"
  echo " - 조치: kill -9 [PID]"
  for pid in $PIDS; do
    echo "   * kill -9 $pid"
    kill -9 "$pid" 2>/dev/null || true
  done
else
  echo " - 데몬 종료: 대상 PID 없음(건너뜀)"
fi

# (B) 부팅 자동 시작 비활성화(S* → _S*)
if [ ${#RCFILES[@]} -gt 0 ]; then
  echo " - 원인: 부팅 시 자동 시작 링크 존재"
  echo " - 근거: 위 '부팅 스크립트 후보' 목록"
  echo " - 조치: 서비스 정지 후 S* 파일명을 _S* 로 변경하여 부팅시 미시작"

  # 실제 정지 수행 
  if command -v systemctl >/dev/null 2>&1; then
    echo "   * systemctl stop nis ypserv ypbind"
    systemctl stop nis ypserv ypbind 2>/dev/null || true

  # 링크 비활성화: S* → _S*
  for f in "${RCFILES[@]}"; do
    base="$(basename "$f")"; dir="$(dirname "$f")"
    if [[ "$base" == S* ]]; then
      new="${dir}/_${base}"
      echo "   * mv '$f' '$new'"
      mv "$f" "$new" 2>/dev/null || true
    else
      echo "   * (건너뜀) $f  # S* 시작 아님"
    fi
  done
else
  echo " - 부팅 스크립트 비활성화: 대상 없음(건너뜀)"
fi

echo
echo "[요약]"
echo " - 프로세스: $( [ -n "${PIDS:-}" ] && echo "강제 종료 수행" || echo "대상 없음" )"
echo " - 부팅 스크립트: $( [ ${#RCFILES[@]} -gt 0 ] && echo "비활성화(rename) 수행" || echo "대상 없음" )"
echo "== 완료 =="