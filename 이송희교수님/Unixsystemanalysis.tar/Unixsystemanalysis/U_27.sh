set -euo pipefail
LANG=C

APPLY=false
if [ "${1:-}" = "--apply" ] || [ "${1:-}" = "-y" ]; then APPLY=true; fi

XDIR="/etc/xinetd.d"
RPC_KEYS='rpc\.cmsd|rpc\.ttdbserverd|sadmind|rusersd|walld|sprayd|rstatd|rpc\.nisd|rexd|rpc\.pcnfsd|rpc\.statd|rpc\.ypupdated|rpc\.rquotad|kcms_server|cachefsd|rusers|rex|rquota|status'

echo "================ U-27 RPC(xinetd) + Firewall 점검 리포트 ================"
echo "모드: $([ "$APPLY" = true ] && echo "APPLY(조치실행)" || echo "DRY-RUN(점검만)")"
echo

# 1) 개요/포인트
echo "[점검 개요]"
echo "- 점검명: U-27 (상) 3.9 RPC 서비스 확인 (xinetd 기준) + 포트 111 차단 검사"
echo "- 목적: 불필요한 RPC 서비스 비활성화 및 외부 포트 노출 차단"
echo
echo "[점검 포인트]"
echo "1) 런타임: rpcinfo -p, ss/netstat, ps"
echo "2) 설정: $XDIR/* 내 RPC 후보의 disable = yes 여부"
echo "3) 네트워크: 포트 111 (tcp/udp) 외부 접근 차단(ufw 우선, 없으면 iptables)"
echo

# 2) 런타임 검사
echo "[1단계] RPC 서비스 런타임 존재 여부 확인"
RUNTIME_HITS=0
if command -v rpcinfo >/dev/null 2>&1; then
  RPCINFO_OUT="$(rpcinfo -p 2>/dev/null || true)"
  if [ -n "$RPCINFO_OUT" ]; then
    echo "- rpcinfo -p:"
    echo "$RPCINFO_OUT" | sed -n '1,200p'
    if printf '%s\n' "$RPCINFO_OUT" | grep -Eiq "$RPC_KEYS"; then RUNTIME_HITS=1; fi
  else
    echo "- rpcinfo 출력 없음"
  fi
else
  echo "- rpcinfo 명령 없음(대체 검사 수행)"
fi

SS_OUT="$(ss -ltnp 2>/dev/null | grep -Ei '(^|:)(111)\b|rpcbind|portmap|rpc' || true)"
PS_OUT="$(ps -ef | grep -Ei 'rpcbind|portmap|rpc\.' | grep -Ev 'grep' || true)"

if [ -n "$SS_OUT" ]; then
  echo "- 포트 검사(ss):"
  echo "$SS_OUT"
  RUNTIME_HITS=1
fi
if [ -n "$PS_OUT" ]; then
  echo "- 프로세스 검사(ps):"
  echo "$PS_OUT"
  RUNTIME_HITS=1
fi

if [ $RUNTIME_HITS -eq 0 ]; then
  echo "=> 런타임 근거: RPC 관련 항목 미검출"
else
  echo "=> 런타임 근거: RPC 관련 항목 검출(상세 위 출력)"
fi
echo

# 3) xinetd 설정 점검
echo "[2단계] xinetd 설정 점검 ($XDIR)"
XINETD_OK=1
NEED_ACTION=()
if [ ! -d "$XDIR" ]; then
  echo "- $XDIR 디렉터리 없음 → xinetd 미사용 → 설정 측면 적용대상 아님(N/A)"
else
  mapfile -t MATCHED < <(grep -Eil "$RPC_KEYS" "$XDIR"/* 2>/dev/null || true)
  if [ ${#MATCHED[@]} -eq 0 ]; then
    echo "- RPC 후보 서비스를 포함하는 xinetd 파일 없음 → 설정 측면 양호"
  else
    echo "- 발견된 파일:"
    for f in "${MATCHED[@]}"; do
      if grep -qi '^[[:space:]]*disable[[:space:]]*=[[:space:]]*yes' "$f"; then
        echo "  * $(basename "$f"): disable = yes (양호)"
      else
        echo "  * $(basename "$f"): disable != yes (조치 필요)"
        NEED_ACTION+=("$f")
      fi
    done
    if [ ${#NEED_ACTION[@]} -gt 0 ]; then XINETD_OK=0; fi
  fi
fi
echo

# 4) 방화벽(포트 111) 상태 점검
echo "[3단계] 포트 111 (rpcbind) 방화벽 차단 상태 확인"
FW_OK=0
UFW_PRESENT=false
if command -v ufw >/dev/null 2>&1; then
  UFW_PRESENT=true
  echo "- ufw 상태:"
  sudo ufw status numbered | sed -n '1,200p' || true
  # ufw가 쓰이고 있고 포트 111 규칙이 존재하는지 확인
  if sudo ufw status | grep -Eiq '111\/tcp|111\/udp'; then FW_OK=1; fi
else
  # iptables 점검
  echo "- ufw 없음 → iptables 규칙 검사"
  IPT_CHECK="$(sudo iptables -S INPUT 2>/dev/null || true)"
  echo "$IPT_CHECK" | sed -n '1,200p'
  if echo "$IPT_CHECK" | grep -Eiq '--dport 111.*DROP|--dport 111.*REJECT'; then FW_OK=1; fi
fi

if [ $FW_OK -eq 1 ]; then
  echo "=> 방화벽 근거: 포트 111 관련 입력 규칙이 존재함 (외부 차단됨)"
else
  echo "=> 방화벽 근거: 포트 111 차단 규칙 없음(조치 권고)"
fi
echo

# 5) 최종 판정(AND 조건 + 방화벽 정보 보조)
echo "[4단계] 최종 판정"
if [ $RUNTIME_HITS -eq 0 ] && [ $XINETD_OK -eq 1 ] && [ $FW_OK -eq 1 ]; then
  echo "=> 최종판정: 양호"
  echo "   - 근거A(런타임): RPC 관련 항목 미검출"
  echo "   - 근거B(설정): /etc/xinetd.d 내 RPC 후보 파일이 없거나 모두 disable = yes"
  echo "   - 근거C(네트워크): 포트 111이 방화벽에 의해 외부 차단됨"
  OVERALL="GOOD"
else
  echo "=> 최종판정: 확인/조치 필요"
  [ $RUNTIME_HITS -ne 0 ] && echo "   - 근거A(런타임): RPC 관련 항목 검출됨"
  [ $XINETD_OK   -ne 1 ] && echo "   - 근거B(설정): disable != yes 항목 존재"
  [ $FW_OK       -ne 1 ] && echo "   - 근거C(네트워크): 포트 111 차단 규칙 없음"
  OVERALL="ACTION"
fi
echo

# 6) 조치 가이드(설정)
echo "[5단계] xinetd 설정 조치 가이드"
if [ ${#NEED_ACTION[@]} -gt 0 ]; then
  for f in "${NEED_ACTION[@]}"; do
    echo "▶ 대상 파일: $f"
    echo "  - 원인: xinetd에서 비활성화(disable = yes)되어 있지 않음"
    echo "  - 근거: 파일 내 'disable' 라인 확인 결과 disable != yes"
    echo "  - 가이드(수동):"
    echo "      cp -a \"$f\" \"$f.bak.$TSF\""
    echo "      sed -i 's/^[[:space:]]*disable[[:space:]]*=.*/\\tdisable = yes/i' \"$f\""
    echo "      # disable 라인이 없다면 파일 끝에 추가:"
    echo "      echo -e \"\\n# Disabled by policy on $TSF\\n\\tdisable = yes\" >> \"$f\""
    echo "      service xinetd restart   # 또는 systemctl restart xinetd"
    echo
  done
else
  echo "- 조치 필요 항목 없음"
fi
echo

# 7) 조치 가이드(방화벽) — 수동/자동 옵션
echo "[6단계] 포트 111 차단 가이드 (권장: 외부만 차단)"
if [ $FW_OK -eq 1 ]; then
  echo "- 포트 111이 이미 차단되어 있음(위의 포인트 참고)"
else
  echo "- 권장 조치(간단): ufw가 설치되어 있다면 ufw로 차단"
  echo "    sudo ufw insert 1 deny proto tcp from any to any port 111"
  echo "    sudo ufw insert 1 deny proto udp from any to any port 111"
  echo "- 대안(ufw 없음): iptables로 차단 (영구화 별도 설정 필요)"
  echo "    sudo iptables -I INPUT -p tcp --dport 111 -j DROP"
  echo "    sudo iptables -I INPUT -p udp --dport 111 -j DROP"
  echo "    # iptables-persistent 설치 시: sudo netfilter-persistent save"
  echo
fi

# 8) --apply: 실제 적용 (xinetd 설정 + 방화벽 규칙)
if $APPLY; then
  echo "[7단계] APPLY 실행: 대상 파일 백업→disable=yes 적용 → xinetd 재시작 → 방화벽 규칙 추가"
  # a) xinetd 파일 수정
  for f in "${NEED_ACTION[@]}"; do
    echo "  처리: $f"
    cp -a "$f" "$f.bak.$TSF"
    if grep -qi '^[[:space:]]*disable[[:space:]]*=' "$f"; then
      sed -i.bak_"$TSF" "s/^[[:space:]]*disable[[:space:]]*=.*/\tdisable = yes/i" "$f"
    else
      printf "\n# Disabled by rpc_u27_xinetd_audit.sh on %s\n\tdisable = yes\n" "$TSF" >> "$f"
    fi
  done

  # restart xinetd if applicable
  if [ -d "$XDIR" ]; then
    if command -v systemctl >/dev/null 2>&1; then
      systemctl restart xinetd 2>/dev/null || service xinetd restart 2>/dev/null || true
    else
      service xinetd restart 2>/dev/null || true
    fi
  fi

  # b) 방화벽 규칙 추가 (ufw 우선, 없으면 iptables)
  if command -v ufw >/dev/null 2>&1; then
    echo "  - ufw detected → adding deny rules for 111/tcp & 111/udp"
    sudo ufw insert 1 deny proto tcp from any to any port 111 || true
    sudo ufw insert 1 deny proto udp from any to any port 111 || true
  else
    echo "  - ufw not found → adding iptables DROP rules for 111/tcp & 111/udp"
    # 백업 현재 iptables
    sudo iptables-save > /tmp/iptables.backup.$TSF || true
    sudo iptables -I INPUT -p tcp --dport 111 -j DROP || true
    sudo iptables -I INPUT -p udp --dport 111 -j DROP || true
    # 영구화 안내만 (환경별 처리)
    echo "    # To persist rules permanently, install iptables-persistent or netfilter-persistent."
    echo "    # Example: sudo apt install iptables-persistent && sudo netfilter-persistent save"
  fi

  echo "- 재시작/규칙 적용 시도 완료 → 재검증을 위해 스크립트를 옵션 없이 다시 실행 권장"
  echo
fi

echo "================ 리포트 종료 ================"
exit 0