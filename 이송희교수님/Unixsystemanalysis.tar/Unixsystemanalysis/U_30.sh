MIN_VER="8.15.2"

say(){ echo "[*] $*"; }

# 1) 조건 보여주기(프로세스/포트/버전)
PROC=$(ps -ef | grep -E '[s]endmail' >/dev/null && echo "YES" || echo "NO")
PORT=$( (ss -ltn 2>/dev/null || netstat -an 2>/dev/null) | grep -E '(:|\. )25\b' >/dev/null && echo "YES" || echo "NO")

get_ver(){
  # 배너/명령/패키지 순서로 심플 시도
  VER=""
  if command -v sendmail >/dev/null; then
    VER=$(sendmail -d0.1 -bv root 2>&1 | grep -Eo '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1)
  fi
  [ -z "$VER" ] && VER=$(echo | nc -w 2 localhost 25 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1)
  [ -z "$VER" ] && VER=$(dpkg-query -W -f='${Version}\n' sendmail 2>/dev/null | grep -Eo '^[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1)
  [ -z "$VER" ] && VER=$(rpm -q --qf '%{VERSION}\n' sendmail 2>/dev/null | head -n1)
  echo "$VER"
}
VER=$(get_ver)

say "조건: 프로세스=${PROC}, 포트25=${PORT}, 감지버전=${VER:-UNKNOWN}"
say "판단근거: 기준버전=${MIN_VER} (버전 비교는 sort -V)"

# 2) 판단(낮거나 미확인 => 업데이트 필요)
need_update(){
  [ -z "$VER" ] && return 0
  # VER < MIN_VER 이면 업데이트
  LOWEST=$(printf "%s\n%s\n" "$VER" "$MIN_VER" | sort -V | head -n1)
  [ "$LOWEST" = "$VER" ] && [ "$VER" != "$MIN_VER" ] && return 0 || return 1
}

# 3) 조치가 필요한 부분 보여주기
if need_update; then
  say "조치필요: sendmail 버전이 낮거나 확인 불가 → 업데이트 진행"
else
  say "조치불필요: 버전 기준 이상"
fi
[ "$PROC" = "YES" ] && say "참고: sendmail 실행 중(필요 없으면 중지 권장: systemctl stop sendmail)"

# 4) 자동 조치(업데이트) 실행
if need_update; then
  say "업데이트 시도 중..."
  if command -v apt-get >/dev/null; then
    apt-get update -y && apt-get install -y --only-upgrade sendmail
    echo "업데이트 완료"
  fi
fi

# 5) 결과 출력(최종 판정)
NEW_VER=$(get_ver)
if [ -n "$NEW_VER" ] && [ "$(printf "%s\n%s\n" "$NEW_VER" "$MIN_VER" | sort -V | tail -n1)" = "$NEW_VER" ]; then
  say "결과: 업데이트 후 버전=${NEW_VER} (기준 이상)"
  echo "=> 최종판정: 양호"
else
  say "결과: 버전=${NEW_VER:-UNKNOWN} (기준 미달 또는 확인 불가)"
  echo "=> 최종판정: 취약함"
fi