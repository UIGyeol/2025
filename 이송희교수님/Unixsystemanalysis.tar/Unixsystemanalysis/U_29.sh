echo ""
echo "[조건] 점검 대상: tftp talk ntalk"
echo "[조건] 디렉터리: /etc/xinetd.d"
echo ""

SERVICES=("tftp" "talk" "ntalk")
DIR="/etc/xinetd.d"
PROBLEMS=()   # 문제 발생한 서비스 목록

for svc in "${SERVICES[@]}"; do
  FILE="$DIR/$svc"

  echo ""
  echo "==== [$svc] 점검 시작 ===="

  # 파일 존재 여부
  if [ ! -f "$FILE" ]; then
    echo "[판단 근거] $FILE 이(가) 존재하지 않습니다."
    echo "[결과] $svc 서비스는 미설치/미사용 → 검사 대상 아님(문제 아님)"
    continue
  fi

  # 현재 disable 라인 그대로 보여주기 (판단 근거)
  CUR_LINE=$(grep -nE '^[[:space:]]*disable[[:space:]]*=' "$FILE" 2>/dev/null | head -n 1)
  if [ -z "$CUR_LINE" ]; then
    echo "[판단 근거] disable 항목이 파일에 없습니다."
    echo "[문제] $svc: disable 가 없음 → 안전하지 않을 수 있음"
    PROBLEMS+=("$svc(항목없음)")
    echo "[조치] 서비스 블록의 '}' 앞에 'disable = yes' 추가"
    # '}'가 있으면 그 앞에 삽입, 없으면 파일 끝에 추가
    if grep -q '}' "$FILE"; then
      sed -i '/^[[:space:]]*}\s*$/i\        disable         = yes' "$FILE"
    else
      echo "        disable         = yes" >> "$FILE"
    fi
    echo "[결과] 양호 $svc: disable = yes 추가 완료"
    continue
  fi

  # 줄번호와 내용 분리
  LINE_NO=$(echo "$CUR_LINE" | cut -d: -f1)
  LINE_TXT=$(echo "$CUR_LINE" | cut -d: -f2-)

  # 판단 근거: 현재 값 그대로 보여주기
  echo "[판단 근거] ${LINE_NO}행: $(echo "$LINE_TXT" | sed 's/^[[:space:]]*//')"

  # 문제 판단: yes 가 아니면 문제
  if echo "$LINE_TXT" | grep -qi '= *yes'; then
    echo "[결과] 양호 $svc: 이미 disable = yes (문제 없음)"
  else
    echo "[문제] $svc: 현재 값이 'yes'가 아님 → 안전하지 않을 수 있음"
    PROBLEMS+=("$svc(값변경)")
    echo "[조치] ${LINE_NO}행 수정 → 'disable = yes'"
    # 해당 줄만 안전하게 치환
    # 줄번호로 지정하여 그 줄을 통째로 바꿈
    sed -i "${LINE_NO}s/.*/        disable         = yes/" "$FILE"
    echo "[결과] $svc: disable = yes 로 변경 완료"
  fi
done

# xinetd 재시작
echo ""
echo "[조치] xinetd 서비스 재시작 중..."
systemctl restart xinetd 2>/dev/null || service xinetd restart
sleep 1

# 최종 결과 요약
echo ""
echo "==== [결과 요약] ===="
if [ ${#PROBLEMS[@]} -eq 0 ]; then
  echo "[OK] 모든 대상이 안전하거나 검사 대상 아님"
else
  echo "[수정/문제 있었던 항목]"
  for p in "${PROBLEMS[@]}"; do
    echo "  - $p"
  done
fi

if systemctl is-active --quiet xinetd; then
  echo "[OK] xinetd 상태: active (running)"
else
  echo "[주의] xinetd 서비스가 실행 중이 아닙니다. 수동 확인 필요"
fi

echo "[완료] 점검 종료"